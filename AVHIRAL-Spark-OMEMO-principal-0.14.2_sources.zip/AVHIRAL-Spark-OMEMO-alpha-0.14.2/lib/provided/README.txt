Lancez prepare-spark-libs.ps1 avant mvn clean package.
